# Notebooks de Estructuras de Datos — Generados automáticamente
Fecha: 2025-09-08

Este paquete contiene cuadernos .ipynb creados a partir de los archivos .py suministrados.
Cada cuaderno incluye:
- Objetivos de aprendizaje
- Teoría esencial del tema
- Código original integrado
- Pruebas rápidas
- Plantilla de análisis de complejidad
- Ejercicios propuestos y referencias

Ubicación: /mnt/data/Notebooks
