def diferencias_consecutivas(vector):
    return [vector[i+1] - vector[i] for i in range(len(vector)-1)]

# Ejemplo
print(diferencias_consecutivas([3, 7, 10, 15]))  # [4, 3, 5]

